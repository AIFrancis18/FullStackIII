package com.cancha.cancha.controller.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cancha.cancha.model.CanchaModel;

public interface Cancharepositories extends JpaRepository<CanchaModel, Integer> {

}
