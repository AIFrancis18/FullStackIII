package com.cancha.cancha.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.cancha.cancha.model.CanchaModel;
import com.cancha.cancha.services.Canchaservices;

@RestController
@RequestMapping("/canchas")
public class CanchaController {

    @Autowired
    private Canchaservices canchaService;

    @GetMapping
    public List<CanchaModel> obtenerCanchas() {
        return canchaService.obtenerCanchas();
    }

    @GetMapping("/{id}")
    public CanchaModel obtenerPorId(@PathVariable int id) {
        return canchaService.obtenerPorId(id);
    }

    @PostMapping
    public CanchaModel crearCancha(@RequestBody CanchaModel cancha) {
        return canchaService.guardarCancha(cancha);
    }
}

