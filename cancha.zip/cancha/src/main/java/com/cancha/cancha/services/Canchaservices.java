package com.cancha.cancha.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cancha.cancha.model.CanchaModel;
import com.cancha.cancha.controller.repositories.*;;

@Service
public class Canchaservices {

    @Autowired
    private Cancharepositories canchaRepository;

    public List<CanchaModel> obtenerCanchas() {
        return canchaRepository.findAll();
    }

    public CanchaModel obtenerPorId(int id) {
        return canchaRepository.findById(id).orElse(null);
    }

    public CanchaModel guardarCancha(CanchaModel cancha) {
        return canchaRepository.save(cancha);
    }
}
