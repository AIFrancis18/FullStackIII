package proyectotarea.proyectotarea.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import proyectotarea.proyectotarea.model.UsuarioModel;

public interface UsuarioRepository extends JpaRepository<UsuarioModel, Long> {
}
