package proyectotarea.proyectotarea.service;

import java.util.List;
import proyectotarea.proyectotarea.model.UsuarioModel;

public interface UsuarioService {

    List<UsuarioModel> listarUsuarios();

    UsuarioModel obtenerPorId(Long id);

    UsuarioModel guardarUsuario(UsuarioModel usuario);

    UsuarioModel actualizarUsuario(Long id, UsuarioModel usuario);

    void eliminarUsuario(Long id);
}
