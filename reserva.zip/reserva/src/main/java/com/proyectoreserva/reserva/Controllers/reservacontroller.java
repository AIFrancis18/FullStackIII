package com.proyectoreserva.reserva.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.proyectoreserva.reserva.Model.reservamodel;
import com.proyectoreserva.reserva.services.reservaservices;

@RestController
@RequestMapping("/reservas")
public class reservacontroller {

    @Autowired
    private reservaservices reservaService;

    @GetMapping
    public List<reservamodel> obtenerReservas() {
        return reservaService.obtenerReservas();
    }

    @PostMapping
    public reservamodel crearReserva(@RequestBody reservamodel reserva) {
        return reservaService.crearReserva(reserva);
    }

    @GetMapping("/cancha/{id}")
    public List<reservamodel> reservasPorCancha(@PathVariable int id) {
        return reservaService.obtenerPorCancha(id);
    }
}


