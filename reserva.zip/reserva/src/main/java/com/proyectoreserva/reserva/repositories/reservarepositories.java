package com.proyectoreserva.reserva.repositories;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.proyectoreserva.reserva.Model.reservamodel;

public interface reservarepositories extends JpaRepository<reservamodel, Integer> {

    List<reservamodel> findByCanchaId(int canchaId);

}