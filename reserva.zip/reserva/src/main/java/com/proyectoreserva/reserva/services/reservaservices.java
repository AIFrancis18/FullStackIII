package com.proyectoreserva.reserva.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyectoreserva.reserva.Model.reservamodel;
import com.proyectoreserva.reserva.repositories.reservarepositories;

@Service
public class reservaservices {

    @Autowired
    private reservarepositories reservaRepository;

    public List<reservamodel> obtenerReservas() {
        return reservaRepository.findAll();
    }

    public reservamodel crearReserva(reservamodel reserva) {
        return reservaRepository.save(reserva);
    }

    public List<reservamodel> obtenerPorCancha(int canchaId) {
        return reservaRepository.findByCanchaId(canchaId);
    }
}